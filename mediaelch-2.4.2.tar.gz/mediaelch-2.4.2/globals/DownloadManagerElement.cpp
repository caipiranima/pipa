#include "DownloadManagerElement.h"

DownloadManagerElement::DownloadManagerElement()
{
    movie = 0;
    episode = 0;
    show = 0;
    concert = 0;
    directDownload = false;
}
